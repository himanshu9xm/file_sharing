ingestions = {
    "bengaluru": {
        "table_name": "bengaluru",
        "feed_name": "bengaluru.csv"
    },
    "bombay": {
        "table_name": "bombay",
        "feed_name": "bombay.csv"
    },
    "delhi": {
        "table_name": "delhi",
        "feed_name": "delhi.csv"
    },
    "hyderabad": {
        "table_name": "hyderabad",
        "feed_name": "hyderabad.csv"
    },
    "jaipur": {
        "table_name": "jaipur",
        "feed_name": "jaipur.csv"
    },
    "kanpur": {
        "table_name": "kanpur",
        "feed_name": "kanpur.csv"
    },
    "nagpur": {
        "table_name": "nagpur",
        "feed_name": "nagpur.csv"
    },
    "pune": {
        "table_name": "pune",
        "feed_name": "pune.csv"
    }
}