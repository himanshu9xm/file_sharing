import airflow
from airflow import DAG
from datetime import timedelta

from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator
from airflow.providers.dbt.cloud.operators.dbt import DbtCloudRunJobOperator
from airflow.providers.dbt.cloud.sensors.dbt import DbtCloudJobRunSensor

from utils.constants import *

from utils.dag_configs.ingestion_config import ingestions

table_list = list(ingestions.keys())

default_args = {
    'start_date': airflow.utils.dates.days_ago(0),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'dbt_cloud_conn_id': "dbt_cloud", 
    'account_id': 154418
}


dag = DAG(
    'datapipeline',
    default_args=default_args,
    description='an end to end datapipeline using DBT for tranformations',
    schedule_interval=None,
    max_active_runs=1,
    catchup=False,
    dagrun_timeout=timedelta(minutes=20))
    



start = DummyOperator(
    task_id = "start",
    dag=dag
)

end = DummyOperator(
    task_id = "end",
    dag=dag
)

trigger_dbt_job = DbtCloudRunJobOperator(
    task_id = "dim_weather",
    job_id=241301,
    wait_for_termination=False,
    dag=dag
)

dbt_job_sensor = DbtCloudJobRunSensor(
    task_id="waiting_for_dim_weather",
    run_id=trigger_dbt_job.output,
    poke_interval=100,
    timeout=10000,
    dag=dag
)

for tables in table_list:

    TABLE_NAME_STR = ingestions[tables]["table_name"]
    FEED_NAME_STR = ingestions[tables]["feed_name"]

    ingest_feeds = GCSToBigQueryOperator(
        task_id=f"ingest_{TABLE_NAME_STR}",
        bucket=f"{WEATHER_DATA_FEED_BUCKET}",
        source_objects=f"{FEED_NAME_STR}",
        destination_project_dataset_table=f"{DATASET_NAME_RAW}.{TABLE_NAME_STR}",
        write_disposition="WRITE_TRUNCATE",
        external_table=False,
        autodetect=True,
        deferrable=False,
        dag=dag
    )


    start >> ingest_feeds >> trigger_dbt_job >> dbt_job_sensor >> end